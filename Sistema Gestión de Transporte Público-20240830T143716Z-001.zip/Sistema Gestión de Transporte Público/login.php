<?php
session_start();
include 'db_config.php';

$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_usuario = $_POST['nombre_usuario'];
    $contrasena = $_POST['contrasena'];

    // Usar una declaración preparada para evitar inyecciones SQL
    $sql = "SELECT id, contrasena FROM usuarios WHERE nombre_usuario=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $nombre_usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($contrasena, $row['contrasena'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['nombre_usuario'] = $nombre_usuario;
            header("Location: mi_perfil.php");
            exit();
        } else {
            $error = "Contraseña incorrecta";
        }
    } else {
        $error = "Usuario no encontrado";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="miestilo.css">
    <link rel="icon" href="images/icono.png">
</head>
<body>
    <div class="container">
        <h2>Iniciar Sesión</h2>
        <?php if($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post" action="login.php">
            <input type="text" name="nombre_usuario" placeholder="Nombre de Usuario" required><br>
            <input type="password" name="contrasena" placeholder="Contraseña" required><br>
            <input type="submit" value="Iniciar Sesión">
        </form>
        <p><a href="signup.php">¿No tienes una cuenta? Registrarse</a></p>
        <p><a href="index.php">Volver al inicio</a></p>
    </div>
</body>
</html>
