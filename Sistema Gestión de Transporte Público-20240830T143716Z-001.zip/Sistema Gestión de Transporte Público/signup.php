<?php
include 'db_config.php';

$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_usuario = $_POST['nombre_usuario'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); // Hasheando la contraseña
    $email = $_POST['email'];

    // Usar una declaración preparada para evitar inyecciones SQL
    $sql = "INSERT INTO usuarios (nombre_usuario, contrasena, email) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nombre_usuario, $contrasena, $email);

    if ($stmt->execute()) {
        $message = "Registro exitoso";
    } else {
        $error = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" href="miestilo.css">
    <link rel="icon" href="images/icono.png">
</head>
<body>
    <div class="container">
        <h2>Registro</h2>
        <?php if($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post" action="signup.php">
            <input type="text" name="nombre_usuario" placeholder="Nombre de Usuario" required><br>
            <input type="password" name="contrasena" placeholder="Contraseña" required><br>
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="submit" value="Registrarse">
        </form>
        <p><a href="login.php">¿Ya tienes una cuenta? Iniciar Sesión</a></p>
        <p><a href="index.php">Volver al inicio</a></p>
    </div>
</body>
</html>
